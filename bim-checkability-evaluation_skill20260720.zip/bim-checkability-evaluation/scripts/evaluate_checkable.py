#!/usr/bin/env python3
"""
BIM-checkability evaluator (seven-property, cascaded, confidence-routed).

Given one or more agents' seven-property labels, this script:
  * derives the BIM-checkable verdict by strict conjunction,
  * applies the cascade order  Sent -> Ref -> Norm -> Proc -> Data -> Human -> Atom
    to report the first failing property (the screening reason),
  * with >=2 agents, computes probe agreement (0-7), flags escalation on any
    disagreement, and majority-votes each property,
  * runs the reason-label consistency check.

Input: a CSV or XLSX with columns  ID, [Regulation,]  and the seven property columns
       Sentential, Normative, Referential, Process, Data, Human, Atomicity.
Multiple agents: either pass several files (--inputs a.csv b.csv c.csv), or one file with
       an 'Agent' column.

Accepted values (case-insensitive):
  Sentential/Normative/Referential : Complete | Incomplete   (Normative also accepts O/F=Complete, N/P=Incomplete)
  Process/Data/Human               : Independent | Dependent
  Atomicity                        : Atomic | Compound | N/A
"""
import argparse, sys
import pandas as pd

LEAVES = ["Sentential", "Normative", "Referential", "Process", "Data", "Human", "Atomicity"]
CASCADE = ["Sentential", "Referential", "Normative", "Process", "Data", "Human", "Atomicity"]
PASS = {"Sentential": "Complete", "Normative": "Complete", "Referential": "Complete",
        "Process": "Independent", "Data": "Independent", "Human": "Independent",
        "Atomicity": "Atomic"}
FAILNAME = {"Sentential": "Sentential incomplete", "Referential": "Referential incomplete",
            "Normative": "Normative incomplete", "Process": "Process-dependent",
            "Data": "Data-dependent", "Human": "Human-dependent", "Atomicity": "Compound"}

def norm_value(prop, v):
    s = str(v).strip()
    low = s.lower()
    if prop == "Normative":
        if low in ("o", "f", "complete"): return "Complete"
        if low in ("n", "p", "incomplete"): return "Incomplete"
    if low in ("complete",): return "Complete"
    if low in ("incomplete",): return "Incomplete"
    if low in ("independent", "ind"): return "Independent"
    if low in ("dependent", "dep"): return "Dependent"
    if low in ("atomic",): return "Atomic"
    if low in ("compound",): return "Compound"
    if low in ("n/a", "na", "nan", ""): return "N/A"
    return s

def is_pass(prop, v):
    return norm_value(prop, v) == PASS[prop]

def cascade_reason(row):
    """Return (verdict 'Yes'/'No', first_failing_property or '')."""
    for prop in CASCADE:
        val = norm_value(prop, row[prop])
        if prop == "Atomicity":
            # reached only if the other six pass; Atomic->checkable, else fail
            if val == "Atomic":
                return "Yes", ""
            return "No", FAILNAME["Atomicity"] if val == "Compound" else "Atomicity N/A (review)"
        if not is_pass(prop, val):
            return "No", FAILNAME[prop]
    return "Yes", ""

def majority(series):
    vc = series.map(lambda v: v).value_counts()
    return vc.index[0]

def load(paths, agent_col):
    frames = []
    for i, p in enumerate(paths, 1):
        df = pd.read_excel(p, keep_default_na=False) if p.lower().endswith((".xlsx", ".xls")) \
            else pd.read_csv(p, keep_default_na=False)
        if agent_col and agent_col in df.columns:
            for a, g in df.groupby(agent_col):
                frames.append((str(a), g.drop(columns=[agent_col])))
        else:
            frames.append((f"agent{i}", df))
    return frames

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--inputs", nargs="+", required=True, help="one or more label files (CSV/XLSX)")
    ap.add_argument("--agent-col", default=None, help="column naming the agent (if all in one file)")
    ap.add_argument("--out", default="checkability_results.csv")
    args = ap.parse_args()

    agents = load(args.inputs, args.agent_col)
    if not agents:
        sys.exit("no input frames found")
    base_id = agents[0][1]["ID"].values
    reg = agents[0][1]["Regulation"] if "Regulation" in agents[0][1].columns else pd.Series([""] * len(base_id))

    # align all agents on ID
    per_agent = {name: g.set_index("ID") for name, g in agents}
    ids = list(base_id)
    rows = []
    for _id in ids:
        labels = {name: per_agent[name].loc[_id] for name in per_agent if _id in per_agent[name].index}
        agent_names = list(labels)
        # majority per property (or single agent's value)
        maj = {}
        for prop in LEAVES:
            vals = pd.Series([norm_value(prop, labels[a][prop]) for a in agent_names])
            maj[prop] = majority(vals)
        # probe agreement (first two agents) and escalation
        if len(agent_names) >= 2:
            a1, a2 = agent_names[0], agent_names[1]
            agree = sum(norm_value(p, labels[a1][p]) == norm_value(p, labels[a2][p]) for p in LEAVES)
            escalated = "yes" if agree < 7 else "no"
        else:
            agree, escalated = 7, "no"
        verdict, reason = cascade_reason(maj)
        rows.append(dict(ID=_id,
                         **{p: maj[p] for p in LEAVES},
                         Verdict=verdict, First_failing_property=reason,
                         Confidence=agree, Escalated=escalated,
                         N_agents=len(agent_names)))
    out = pd.DataFrame(rows)
    out.insert(1, "Regulation", list(reg))
    out.to_csv(args.out, index=False)

    n = len(out)
    print(f"rows: {n}")
    print(f"checkable (Yes): {(out.Verdict=='Yes').sum()}  |  non-checkable (No): {(out.Verdict=='No').sum()}")
    if (out.N_agents >= 2).any():
        esc = (out.Escalated == 'yes').sum()
        print(f"escalated (probe disagreement): {esc} ({esc/n:.1%})")
    print("first-failing-property distribution:")
    print(out[out.Verdict=='No']['First_failing_property'].value_counts().to_string())
    print(f"written: {args.out}")

if __name__ == "__main__":
    main()
