---
name: bim-checkability-evaluation
description: >
  Decide whether design-requirement statements are BIM-checkable using the seven-property ADCC
  theory, with a cascaded (short-circuit) evaluation order and a confidence-routed multi-agent
  pipeline. Use whenever the user wants to judge, label, or explain the BIM-checkability of
  building-regulation / design-guide sentences, score the seven properties, derive the checkable
  verdict, or build or audit a property-based gold standard. Triggers: "BIM-checkable", "is this
  checkable", "checkability evaluation", "seven properties", "sentential / normative / referential
  completeness", "human dependency", "process / data dependence", "atomicity", "cascade
  evaluation", "property-based verdict", "confidence routing". This is the property-scoring
  counterpart to adcc-classifier (which assigns check-TYPE codes NN/NR/CD/CG); it decides
  checkability itself and names the failing property. Supersedes the deprecated five-property
  adcc-checkable-eval.
---

# BIM-checkability evaluation (seven-property, cascaded, confidence-routed)

Decide whether each design requirement is **BIM-checkable** - i.e. whether a rule engine
could decide its compliance against a Building Information Model alone - by scoring seven
atomic properties, deriving the verdict by strict conjunction, and naming the property that
fails. This skill also specifies the efficient runtime: a short-circuit **cascade** and a
**confidence-routed multi-agent** escalation.

> This skill decides *checkability* and its *reason*. It is not the check-type classifier
> (adcc-classifier, which assigns NN/NR/CD/CG codes). It supersedes the 5-property
> adcc-checkable-eval.

---

## 1. The seven properties

Label each property independently, from the sentence alone. A vague-but-stated criterion is
**Normatively Complete** and fails on **Human Dependency** - never charge vagueness twice.

| # | Property | Values | Passes when |
|---|----------|--------|-------------|
| 1 | Sentential completeness | Complete / Incomplete | grammatically whole sentence (subject + predicate); a fragment/heading is Incomplete |
| 2 | Normative completeness | Complete / Incomplete | a criterion is **stated** (deontic action + conditions); Incomplete only if the obligation/target/criterion is missing entirely |
| 3 | Referential completeness | Complete / Incomplete | every value/term needed is in the sentence; Incomplete if it lives in a cited clause/table/figure/standard/other law. A generic anaphor ("the areas") and a domain term-of-art (e.g. an FGI space type) are **Complete** |
| 4 | Process dependency | Independent / Dependent | check is a direct comparison to model geometry/attributes; **Dependent** if it needs an off-model activity - engineering calculation, structural/thermal/acoustic/fire/smoke analysis, simulation, physical/lab test, on-site measurement, inspection, or approval (deflection, bearing capacity, load, flow rate, reverberation time, "capable of withstanding", "rated by test") |
| 5 | Data dependency | Independent / Dependent | all input data exist in the sentence + a standard BIM model; **Dependent** if it needs a value the model does not carry - soil/geotechnical results, product certificate, climate record, schedule, date, cost |
| 6 | Human dependency | Independent / Dependent | decidable without a person's judgment; **Dependent** for judgment words - "adequate", "suitable", "sufficient", "reasonable", "visual privacy", "legible", "clearly visible". (This axis replaces the old "Objectivity"; do not use objective/subjective.) |
| 7 | Atomicity | Atomic / Compound / N/A | Atomic = one requirement, or one carrying preconditions/exceptions, or alternatives joined by **OR**. Compound = 2+ obligations joined by **AND** that should be split (an AND inside a condition is not Compound). N/A = not a requirement (heading, definition, scope, advisory) |

**Verdict (strict conjunction).** A requirement is BIM-checkable ("Yes") only if:

```
Sentential=Complete AND Normative=Complete AND Referential=Complete
AND Process=Independent AND Data=Independent AND Human=Independent
AND Atomicity=Atomic
```

Parent axes for reporting: Completeness = Sentential AND Normative AND Referential;
Self-sufficiency = Human AND Process AND Data. Never judge the verdict holistically - derive
it from the leaves so internal consistency is automatic. The Level of Detail of any particular
model is **not** a factor; assume a standard, fully-populated model.

### Do not double-count

| Defect | Correct axis | Common mistake |
|--------|-------------|----------------|
| stated but vague ("visual privacy") | Human = Dependent | also Normative Incomplete |
| generic anaphor ("the areas") | Referential stays Complete | Referential Incomplete |
| needs a sightline/acoustic analysis | Process = Dependent | also Human Dependent |
| cites Table 705.8 | Referential = Incomplete | also Normative Incomplete |

**Worked example.** *"Post-Procedure Patient Care shall be permitted provided there is
visual privacy between the areas."* -> Sentential Complete, Normative Complete (a condition is
stated), Referential Complete ("the areas" is generic; the space type is a term-of-art),
Human **Dependent** ("visual privacy" needs a person), Process **Dependent** (a sightline
analysis, not an attribute read), Data Independent, Atomicity Atomic. Verdict **No**, carried
by Human dependency. One clean failure, not three.

### Edge-case litmus tests

Apply these when a surface form is ambiguous:

- **Normative vs Human.** Is *any* criterion stated, however vague? None at all (no threshold/target/condition) -> Normative Incomplete. Stated but resting on judgment words ("adequate", "reasonable") -> Normatively Complete, fails Human. Never charge vagueness to both.
- **Referential vs Data.** Can the referent be resolved to a fixed value at authoring time from the normative corpus? Yes -> Referential Incomplete (recoverable by inlining). No (dynamic/empirical/project-specific, e.g. "per the manufacturer's published data") -> Data-dependent (intrinsic).
- **Well-known classes.** Assigned labels (a room/space type, "negative pressure room") are checkable. Versioned scheme names ("Class I/II/IIIA flammable liquids") are NOT checkable even if familiar - re-run the Referential-vs-Data test on them, because schemes change and vary by region.
- **Process test.** Is the compliance fact a static property of the design, or produced by an off-model event - physical/lab test, inspection, certification, approval, engineering calculation/analysis/simulation, temporal/dynamic behaviour ("for 3 seconds", "at all times"), or a construction-sequence state ("before framing")? The latter -> Process-dependent. (A "220 N sliding force" is confirmed by measuring the installed door -> Process-dependent.)
- **Hand-you-the-data test (Human vs Data).** If someone supplied the missing element, would the check then run mechanically? Yes -> Data (the gap is information). No, a person must still judge -> Human (the gap is the predicate).
- **Vague adjective hiding a quantity (Human vs Process vs Data).** If "solid/adequate/sufficient" means "good enough to do X", unpack X: a load/capacity/performance criterion needs specific values -> Data (and Process if it needs analysis). Only if no criterion is recoverable is it pure Human vagueness.
- **Purpose and exception clauses.** Classify on the operative predicate. A purpose clause ("to alert...", "so that...") is rationale, not a criterion - it must not trigger a false Human-dependent. A checkable main obligation carrying an exception that defers to an external document (e.g. "except where the manufacturer's instructions specify otherwise") stays checkable; flag the exception for manual review rather than letting it defeat the verdict.
- **Multi-failure rows.** A statement can fail several properties; the cascade records the FIRST failure in the order below as the reason.

---

## 2. Cascaded evaluation order (efficient screening)

The verdict is an AND, so a single failing property makes the requirement non-checkable -
evaluating the rest cannot change the verdict. For screening, evaluate in this **fixed order
and stop at the first failure**, recording that property as the reason:

```
Sentential -> Referential -> Normative -> Process -> Data -> Human -> Atomicity
```

Rationale for the order (validated on a 700-rule gold standard):
- **Sentential first** - logical prerequisite (a fragment has no criterion to check) and the
  most reliable leaf (~0.99), so a cheap, trustworthy gate.
- **Referential second** - the single most common failure (~24% of rules), so it terminates
  early most often.
- **Human and Atomicity last** - Human is the least reliable leaf (~0.87), so it should not
  trigger an early stop; Atomicity is gated (N/A until the other six pass), so it is
  naturally last.

This order cuts property evaluations by roughly **30%** versus scoring all seven, without
changing the verdict. Use the full seven-property pass (not the cascade) when the goal is the
complete diagnostic vector or a consistency audit rather than a screen.

---

## 3. Base annotation method

Use **property-decomposed reasoning**: for each property, reason from the deciding evidence
to the label (**reasoning-first** - evidence, then conclusion), and derive the verdict by
conjunction. A paired ablation on 300 gold-standard statements found reasoning-first at least
as accurate as answer-first (verdict accuracy 0.903 vs 0.887; mean per-property 0.879 vs
0.876; not significant, McNemar p = 0.23, but never favouring answer-first), so reasoning-first
is the default. When building few-shot demonstrations, still inject the gold label and have the
model *explain why that label is correct* (AnnoLLM's explain-then-annotate, worth ~3 accuracy
points over label-free explanations) - but write the demo explanations reasoning-first
(evidence then label), not label-first.

Demonstration count does **not** matter within k ~ 2-14 (few-shot beats zero-shot, but 8 and
14 are statistically tied); use **k ~ 8** for token economy. k >= 16 can regress.

---

## 4. Confidence-routed multi-agent escalation (for gold-standard building / high stakes)

Do **not** trust the model's self-reported confidence - it does not separate correct from
wrong answers. Use inter-agent agreement instead.

1. **Probe** every row with **two diverse agents** (different personas or, better, different
   model families - persona variation alone gives only ~1.2 effective independent agents).
2. **Escalate on any disagreement.** Confidence = the number of the seven properties on which
   the two agents agree; escalate whenever they differ on **>= 1 property** (~19% of rows).
   Rows where two diverse agents agree are ~93% correct; where they disagree, ~82%.
3. **Adjudicate** the escalated rows with a **third diverse agent -> majority of three**.
   Three is optimal: M=5 is no better, M=2 = M=1.
4. **Conjoin** the (majority) property labels to the verdict, so internal consistency holds
   automatically.
5. **Consistency checks** that actually have yield: reason-label agreement (the stated reason
   must match the label) and sibling / cross-row consistency (the same quantity type must be
   scored the same way across rules - e.g. every engineering-calculation quantity is
   Process-Dependent). A per-row "verdict = conjunction" check has **zero** yield once labels
   are derived by conjunction, so do not rely on it to catch semantic errors.
6. **Human on the residual** - send rows that still disagree, or that fail a consistency
   check, to a human. LLM consensus alone is not ground truth.

Cost: this selective policy averages ~2.2 LLM calls per row and matches a fixed three-agent
panel at ~27% lower cost. **Honest expectation:** ensembling lifts verdict accuracy by less
than its seed-to-seed noise (a single well-prompted agent already reaches ~0.91). The value
of the multi-agent layer is a **concentrated ~19% review queue that holds most of the
errors**, not a large accuracy gain. The levers for accuracy are codebook quality and the
human anchor.

Combine both efficiencies: run the **cascade inside each agent's pass** (~30% fewer tests)
and the **selective routing across rows** (~19% escalated); the savings multiply.

---

## 5. Output schema

Emit one row per requirement:

`ID, Regulation, Sentential, Normative, Referential, Process, Data, Human, Atomicity,
Verdict, First_failing_property, Confidence(probe agreement 0-7), Escalated(yes/no),
Rationale`

- `Verdict` = Yes/No, derived by conjunction (or by the cascade's first failure).
- `First_failing_property` = the cascade reason (blank if checkable).
- `Rationale` = one clause naming the decisive evidence.
- Read spreadsheets with `keep_default_na=False`: the literal "N/A" in Atomicity is a
  category, not a null.

## 6. Helper script

`scripts/evaluate_checkable.py` - given a CSV/XLSX of property labels from one or more
agents, it derives the verdict, applies the cascade order to report the first failing
property, computes probe agreement / escalation flags and the majority vote when multiple
agents are supplied, and runs the reason-label / sibling consistency checks. Run
`python scripts/evaluate_checkable.py --help`.
